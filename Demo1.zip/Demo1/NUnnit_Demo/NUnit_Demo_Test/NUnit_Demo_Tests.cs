using NUnit.Framework;
using NUnnit_Demo;
namespace NUnit_Demo_Test;
public class NUnit_Demo_Tests
{
    private Method method { get; set; } = null!;
    [SetUp]
    public void Setup()
    {
        method = new Method();
    }

    [Test]
    public void sum_Test()
    {
        Assert.AreEqual(2, method.sum(1, 1));
    }


    [Test]
    public void minus_Test()
    {
        Assert.Greater(2, method.minus(1, 1));
    }

    [Test]
    public void gradestudent_test()
    {
        Assert.AreEqual("Hoc sinh kha", method.GradeStudent(9));
    }

    [Test]
    public void Tall_Check_Test()
    {
        Assert.IsTrue(method.Tall_Check(1.76));
    }

    [Test]
    public void List_Check()
    {
        Assert.Contains("Quy", method.List());
    }
        
}

