﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NUnnit_Demo
{
    public class Method
    {
        public int sum(int a, int b)
        {
            return a + b;
        }
        public int minus(int a, int b)
        {
            return a - b;
        }

        public int multiply(int a, int b)
        {
            return a * b;
        }
        public String GradeStudent(int point)
        {
            if (point >= 8) return "Hoc sinh gioi";
            if (point >= 6.5) return "Hoc sinh kha";
            if(point >=5) return "Hoc sinh trung binh";
            else return "Hoc sinh yeu";
        }

        public Boolean Tall_Check(double height)
        {
            if (height >= 1.75) 
                return true;
            else
                return false;
        }

        public String[] List()
        {
            String[] result = { "Quy", "Bao", "Manh", "Huy" };
            return result;
        }
    }
}
