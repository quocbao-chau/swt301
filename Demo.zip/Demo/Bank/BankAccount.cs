﻿using System;

namespace Bank
{
    /// <summary>
    /// Bank account demo class.
    /// </summary>
    public class BankAccount
    {
        private double balance;

        public BankAccount() //Khoi tao bank account so du = 0
        {
        }

        public BankAccount(double balance) // khoi tao bank account co the nhap so du hien tai
        {
            this.balance = balance;
        }

        public double Balance //tra ve so du hien tai
        {
            get { return balance; }
        }

        public void Add(double amount) //them so tien bat ki vao so du cua minh
        {
            if (amount < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(amount));
            }

            balance += amount;
        }

        public void Withdraw(double amount) //method rut so tien bat ki tu so du cua minh
        {
            if (amount > balance)
            {
                throw new ArgumentOutOfRangeException(nameof(amount));
            }

            if (amount < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(amount));
            }

            balance -= amount;
        }

        public void TransferFundsTo(BankAccount otherAccount, double amount) //chuyen tien tu tk nay sang tk khac voi bat ki so tien nao
        {
            if (otherAccount is null)
            {
                throw new ArgumentNullException(nameof(otherAccount));
            }

            Withdraw(amount);
            otherAccount.Add(amount);
        }
    }
}
